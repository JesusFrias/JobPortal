package net.frias.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.frias.model.Usuario;

public interface UsuariosRepository extends JpaRepository<Usuario, Integer> {
	
	Usuario findByUsername(String username);

}
