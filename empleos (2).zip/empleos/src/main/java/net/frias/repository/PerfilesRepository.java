package net.frias.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.frias.model.Perfil;

public interface PerfilesRepository extends JpaRepository<Perfil, Integer> {

}
