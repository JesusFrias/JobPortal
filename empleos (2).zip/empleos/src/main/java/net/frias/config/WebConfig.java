package net.frias.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
	
	@Value("${empleosapp.ruta.imagenes}") //nombre de la propiedad en application.properties
	private String rutaImagenes;
	
	@Value("${empleosapp.ruta.cv}") //nombre de la propiedad en application.properties
	private String rutaCv;
	
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		//registry.addResourceHandler("/logos/**").addResourceLocations("file:/empleos/img-vacantes/"); //Linux
		//registry.addResourceHandler("/logos/**").addResourceLocations("file:d:/empleos/img-vacantes/"); //Windows
		registry.addResourceHandler("/logos/**").addResourceLocations("file:" + rutaImagenes);
		registry.addResourceHandler("/cv/**").addResourceLocations("file:" + rutaCv);
	}
	
}
