package net.frias.service;

import java.util.List;

import net.frias.model.Usuario;

public interface IUsuariosService {
	/** Ejercicio: Implementar metodo para registrar un nuevo usuario
	 * 1. Usar plantilla del archivo formRegistro.html
	 * 2. El metodo pata mostrar el formulario para registrar y el metodo para guardar el usuario debera
	 *    estar en el controlador HomeController
	 * 3. Al guardar el usuario se le asiganará el perfil de USUARIO  y la fecha de registro
	 *    será la fecha actual del sistema
	 * @param usuario
	 */
	
	void guardar(Usuario usuario);
	void eliminar(Integer idUsuario);
	List<Usuario> buscarTodos();
	Usuario buscarPorUsername(String username);
}
